public class TreeEmptyException extends RuntimeException {

}
