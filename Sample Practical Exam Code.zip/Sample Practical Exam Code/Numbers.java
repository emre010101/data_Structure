public class Numbers
{
    //Recursive function that checks
    //whether the string is palindrome or not

    // this is going to be our iterative solution.
    //we simply take in the array of numbers into the method signature and check if
    //each number is evenly divisible by 3...
    static void checkDivision(int [] myarray)
    {
      //the for loop is going to go through the array one element at a time...
        for(int i=0;i<myarray.length;i ++){
          // we are going to use the mod operator to check the remainder of
          //the division and make sure it is zero.
          //if its zero thats cool and we print out that the number is evenly divisible by 3
          if(myarray[i]%3 == 0){
            System.out.println(myarray[i]+" is evenly disivable by 3");
          }
        }
    }

//remember that the recursive solution needs to handle the looping part of the above...
// the above loop is a for loop and inside the loop we are checking the number
    static void checkDivisionRec(int [] myarray, int index)
    {
      if(index < 0)
        return;
      if(myarray[index] %3 == 0){
            System.out.println(myarray[index]+" is evenly disivable by 3");
      }
      checkDivisionRec(myarray, index-1);
    }


    public static void main(String args[])
    {
        int [] mynumbers = {3, 32, 5, 354, 139, 2345, 113};
        checkDivision(mynumbers);
        System.out.println("--------------------------------------");
        checkDivisionRec(mynumbers, mynumbers.length-1);

    }
}
