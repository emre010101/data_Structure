/*
    We have defined multiple Nodes depending on the data structure that we
    are using. So for example, in a:
     -> Single linkedlist we have a data element, and a pointer
     -> Double Linkedlist we have a data element, two pointers
     -> Binary Search Tree we have a data element, two pointers
*/
// we need to define the Node...
public class Node {

  //the instances variables are the attributes of the object...
  //The data piece is going to be the movie object that we created
  //the pointer is going to point at a Node object and we are going to call it next
    Movie movie;
    Node next;

// the constructor allows us to create an instance of the class we are defining...
// we want to be able to create Node Objects...
    public Node(Movie movie, Node next){
        this.movie = movie;
        this.next = next;
    }

    public Node(Movie movie) {
        this(movie, null);
    }

    // String representation of the node
    @Override
    public String toString() {
        return  movie +
                ", next=" + next +
                '}';
    }

    public static void main(String[] args) {
      // we are creating the Node object passing in a new Movie instance and no Node object...
        Node test = new Node(new Movie("Batman", "The best film of the year", "Action", 120, 5));
        System.out.println(test);
    }
}
