//Create the Movie object, the reason is to encapulate the object that
//we need in out Linked...essentially our linked list is going to be able
//to have a list of Movies that are connected.

public class Movie {

    //next we define our instance variables...
    //these come from the problem definition...
    private String title;
    private String description;
    private int duration;
    private int rating;
    private String genre;


    //we know that we need to be able to create instances of type Movie...
    //this is in our constructor...
    public Movie(String title, String description, String genre, int duration, int rating) {
//we are assigning the value of the inputted variable into the instnace variable
        this.title = title;
        this.description = description;
        this.genre = genre;
        this.duration = duration;
        this.rating = rating;
    }


// we need a few accessor methods to gain access to the instances variables
// associated / defined within the object of type Movie...
// we make the method public, consider the return type and name the method
//typically we would call the method getVariableWeAreAccessing
//the body of the method is simply a return statement.

    public String getGenre() {
        return genre;
    }

    public String getTitle() {
        return title;
    }

    public int getRating() {
        return rating;
    }

//we know that by default Java gives us a toString method. We override this methods
// to create the string representation asked for in the problem definition.
/*
  Movie Title
  Description: This is a cool movie about trains Genre: Action
  Duration: 120
  Rating: 5
*/

    @Override
    public String toString() {
        return "*** Movie Details ***\n" +
                "Movie Title : " + title + "\n" +
                "Description: " + description + "\n" +
                "Genre: " + genre + "\n" +
                "Duration: " + duration + "\n" +
                "Rating: " + rating + "\n";
    }

    public static void main(String [] args){
      Movie first = new Movie("Batman", "The best film of the year", "Action", 120, 5);
      System.out.println(first);
    }
}
