// we need to demonstrate the functinality of the created LinkedList
public class MovieDemo {

    public static void main(String[] args) {

        LinkedList movies = new LinkedList();


        // test of add method --> working!
        movies.add(new Movie("Batman", "The best film of the year", "Action", 120, 5));
        movies.add(new Movie("Joker", "The best vilan of the year", "Action", 100, 3));
        movies.add(new Movie("Superman", "Not a big fan", "Drama", 150, 2));
        movies.add(new Movie("Spiderman", "Great film", "Action", 120, 4));
        movies.add(new Movie("Guardians of the Galaxy", "Interesting movie", "Drama", 98, 4));

        // test of string representation
        //System.out.println("Sample of String representation\n " + movies);

        // tests of is empty
//        System.out.println("List is empty: " + movies.isEmpty());


  //      System.out.println("Movies by Genre: " + movies.genreSearch("Drama"));



        //get the average star rating
        System.out.println("Average star rating: " + movies.getAverage());

        //test of remove
    //     movies.remove("Guardians of the Galaxy"); // first element
    //     System.out.println(movies);

    }
}
