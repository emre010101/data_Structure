// The data structure that we are going to be working with is a Linked List
public class LinkedList {

//the instances variables first and last are going to be used throughout the
//codebase to identify the first and last objects within our linkedlist.

    private Node first;
    private Node last;

//the contsructor generates a new LinkedList..and assigns the value
//null to both the first and last nodes....
    public LinkedList() {
        this.first = null;
        this.last = null;
    }

//this method checks to see if the linkedlist is empty...
    public boolean isEmpty() {
        return first == null;
    }

//this method answers part iii in question 1 part B.
//we would like to be able to iterate over the collection of movies...
// what this means is that we would like to be able to traverse the collection
//what this means is we want to go through each movie one at a time..
//and on each movie we want to check the genre type and record if there is a match in the genre...
    public String genreSearch(String genre) {
        String str = "---Movie Search by Genre---\n";

        // we are going to start our search from the first object, so we
        //use the reference to the first node.
        Node current = first;
        while (current != null) { // as we know when the node points to null we are at the end of the list
//we need to compare the genre for the current movie against the search for genre.
            if (current.movie.getGenre().equalsIgnoreCase(genre)) {
                str += current.movie;
            }
            //here is where we move to the next object in the collection...
            current = current.next;
        }
        return str;
    }

    //we would lke to iterate over the collection and calculate the average
    // star rating.
    // we are going to return a double. we need a running total to store the
    //ratings being added and then divide by the number of objects.
    public double getAverage() {
      //this is what we are going to return
        double rating = 0;

        //we are going to start at the start of the collection.
        Node current = first;
        while (current != null) {
          // on each Movie we simply grab the rating using getRating and
          // add this to the running total...
            rating += current.movie.getRating();
            current = current.next;
        }
        return rating/size();
    }
    //this method is used to calculate the number of objects within the collection...
    public int size() {
        if (isEmpty()){
            return 0;
        }
        int counter = 0;
        Node current = first;
        while (current != null) {
            counter++;
            current = current.next;
        }
        return counter;
    }

    // the add method allows us to add an object into our linkedlist...
    public void add(Movie movie) {
        if (isEmpty()) {
            first = new Node(movie);
            last = first;
        } else {
            last.next = new Node(movie);
            last = last.next;
        }
    }

//we would like to remove a node by search for its title...
    public String remove(String title) {
        if (isEmpty()) {
            return "No records";
        }

        Node curr = first;
        while (curr != null) {
          // we would like to find the movie by title...this is just like the
          // in the genre search...
            if (curr.movie.getTitle().equalsIgnoreCase(title)) {
                break;
            } else {
                curr = curr.next;
            }
        }

        if (curr == null) { // this means we reached the end of the list without luck, but we are one
            return "TARGET NOT FOUND"; // --> All good until this point, no need for a counter yet
        }
        //now I need to check if a am removing the first, last or only node
        if (first.movie.getTitle().equalsIgnoreCase(title)) { // assuming target is in the first position
            first = first.next; // need to check if we deleted the ONLY element, otherwise, LAST will keep pointing at it
            if (first == null) {
                last = null; //--> working ok
            }
        } else { // we the need to stop one position before the target node,
            Node node = first;
            while (!node.next.movie.getTitle().equalsIgnoreCase(title)) { //this statement means we will stop one node before the target. if node.next IS NOT! the target
                node = node.next;
            }
            if (node.next == null) { //the target is the last element
                this.last = node; // last points to node
                this.last.next = null; //
            } else {
                node.next = node.next.next; // we jump from A to C
            }
        }
        return "Removed: " + title;
    }

    public String toString() {
        Node curr = first;
        String str = "--START--\n";
        while (curr != null) {
            str += curr.movie + "\n";
            curr = curr.next;
        }
        return str + "--END--";
    }
}
